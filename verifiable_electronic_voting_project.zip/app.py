import os, json, hashlib, secrets, sqlite3
from functools import wraps
from flask import Flask, request, jsonify, render_template
from werkzeug.security import generate_password_hash, check_password_hash
from phe import paillier

BASE = os.path.dirname(os.path.abspath(__file__))
DB_PATH = os.path.join(BASE, "voting.db")
KEY_PATH = os.path.join(BASE, "keys.json")
ADMIN_PASSWORD = os.environ.get("VOTING_ADMIN_PASSWORD", "change-this-admin-password")
app = Flask(__name__)

def db():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn

def init_db():
    with db() as c:
        c.execute("""CREATE TABLE IF NOT EXISTS voters(
            voter_id TEXT PRIMARY KEY, pin_hash TEXT NOT NULL, has_voted INTEGER NOT NULL DEFAULT 0)""")
        c.execute("""CREATE TABLE IF NOT EXISTS ballots(
            ballot_id TEXT PRIMARY KEY, ciphertext TEXT NOT NULL, created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP)""")
        c.execute("""CREATE TABLE IF NOT EXISTS metadata(key TEXT PRIMARY KEY, value TEXT NOT NULL)""")

def load_keys():
    if not os.path.exists(KEY_PATH):
        pub, priv = paillier.generate_paillier_keypair(n_length=2048)
        with open(KEY_PATH, "w", encoding="utf-8") as f:
            json.dump({"n": str(pub.n), "p": str(priv.p), "q": str(priv.q)}, f)
        os.chmod(KEY_PATH, 0o600)
    with open(KEY_PATH, encoding="utf-8") as f:
        d = json.load(f)
    pub = paillier.PaillierPublicKey(n=int(d["n"]))
    priv = paillier.PaillierPrivateKey(pub, p=int(d["p"]), q=int(d["q"]))
    return pub, priv

PUBLIC_KEY, PRIVATE_KEY = load_keys()
init_db()

def admin_required(fn):
    @wraps(fn)
    def wrapper(*args, **kwargs):
        supplied = request.headers.get("X-Admin-Password", "")
        if not secrets.compare_digest(supplied, ADMIN_PASSWORD):
            return jsonify(error="Unauthorized"), 401
        return fn(*args, **kwargs)
    return wrapper

def leaf_hash(ballot_id, ciphertext):
    return hashlib.sha256((ballot_id + ":" + ciphertext).encode()).hexdigest()

def merkle_levels(leaves):
    if not leaves:
        return [[hashlib.sha256(b"empty-election").hexdigest()]]
    levels = [leaves]
    while len(levels[-1]) > 1:
        current = levels[-1]
        nxt = []
        for i in range(0, len(current), 2):
            left = current[i]
            right = current[i+1] if i+1 < len(current) else current[i]
            nxt.append(hashlib.sha256((left + right).encode()).hexdigest())
        levels.append(nxt)
    return levels

def public_board():
    with db() as c:
        rows = c.execute("SELECT ballot_id, ciphertext FROM ballots ORDER BY ballot_id").fetchall()
    items = [{"ballot_id": r["ballot_id"], "ciphertext": r["ciphertext"]} for r in rows]
    leaves = [leaf_hash(x["ballot_id"], x["ciphertext"]) for x in items]
    levels = merkle_levels(leaves)
    return items, levels

def merkle_proof(index, levels):
    proof = []
    for level in levels[:-1]:
        sibling = index ^ 1
        if sibling >= len(level):
            sibling = index
        proof.append({"hash": level[sibling], "side": "left" if sibling < index else "right"})
        index //= 2
    return proof

@app.get("/")
def home():
    return render_template("index.html")

@app.get("/api/health")
def health():
    return jsonify(status="ok", project="Verifiable Electronic Voting System with Ballot Privacy",
                   warning="Academic prototype only; not certified for real elections.")

@app.post("/api/demo/register")
def register():
    data = request.get_json(force=True)
    voter_id, pin = str(data.get("voter_id", "")).strip(), str(data.get("pin", ""))
    if not voter_id or len(pin) < 6:
        return jsonify(error="Provide voter_id and a PIN of at least 6 characters."), 400
    try:
        with db() as c:
            c.execute("INSERT INTO voters(voter_id, pin_hash) VALUES(?,?)",
                      (voter_id, generate_password_hash(pin)))
    except sqlite3.IntegrityError:
        return jsonify(error="Voter ID already exists."), 409
    return jsonify(message="Demo voter registered.")

@app.get("/api/public-key")
def public_key():
    return jsonify(scheme="Paillier", n=str(PUBLIC_KEY.n),
                   note="Public key only. Private key remains local in keys.json for this demo.")

@app.post("/api/vote")
def cast_vote():
    data = request.get_json(force=True)
    voter_id, pin = str(data.get("voter_id", "")).strip(), str(data.get("pin", ""))
    try:
        choice = int(data.get("choice"))
    except (TypeError, ValueError):
        return jsonify(error="choice must be an integer candidate number."), 400
    if choice not in (1, 2, 3):
        return jsonify(error="For this demo, choose candidate 1, 2, or 3."), 400
    with db() as c:
        c.execute("BEGIN IMMEDIATE")
        voter = c.execute("SELECT * FROM voters WHERE voter_id=?", (voter_id,)).fetchone()
        if not voter or not check_password_hash(voter["pin_hash"], pin):
            c.rollback()
            return jsonify(error="Invalid voter credentials."), 401
        if voter["has_voted"]:
            c.rollback()
            return jsonify(error="This voter has already voted."), 409
        encrypted = PUBLIC_KEY.encrypt(choice)
        ciphertext = str(encrypted.ciphertext())
        ballot_id = secrets.token_urlsafe(18)
        c.execute("INSERT INTO ballots(ballot_id,ciphertext) VALUES(?,?)", (ballot_id, ciphertext))
        c.execute("UPDATE voters SET has_voted=1 WHERE voter_id=?", (voter_id,))
        c.commit()
    receipt = {"ballot_id": ballot_id, "leaf_hash": leaf_hash(ballot_id, ciphertext)}
    return jsonify(message="Encrypted ballot accepted.", receipt=receipt,
                   privacy_note="The ballot table does not store voter_id; timing correlation remains possible in this demo.")

@app.get("/api/board")
def board():
    items, levels = public_board()
    return jsonify(ballots=[{"ballot_id": x["ballot_id"], "ciphertext": x["ciphertext"],
                             "leaf_hash": leaf_hash(x["ballot_id"], x["ciphertext"])} for x in items],
                   merkle_root=levels[-1][0], count=len(items),
                   note="Public demo board. Publishing ciphertexts is not proof that each ballot is valid.")

@app.get("/api/verify/<ballot_id>")
def verify(ballot_id):
    items, levels = public_board()
    for idx, item in enumerate(items):
        if item["ballot_id"] == ballot_id:
            return jsonify(found=True, ballot_id=ballot_id,
                           leaf_hash=leaf_hash(item["ballot_id"], item["ciphertext"]),
                           proof=merkle_proof(idx, levels), merkle_root=levels[-1][0])
    return jsonify(found=False, message="Ballot receipt not found on the current public board."), 404

@app.get("/api/results")
@admin_required
def results():
    items, _ = public_board()
    totals = {1: 0, 2: 0, 3: 0}
    for item in items:
        encrypted = paillier.EncryptedNumber(PUBLIC_KEY, int(item["ciphertext"]))
        choice = int(PRIVATE_KEY.decrypt(encrypted))
        if choice not in totals:
            return jsonify(error="Invalid ballot plaintext detected; tally halted."), 400
        totals[choice] += 1
    return jsonify(totals=[{"candidate": i, "votes": totals[i]} for i in totals],
                   total_ballots=len(items),
                   caveat="Demo tally decrypts each ballot locally. Production systems should use verifiable mixnets or threshold/homomorphic tallying with proofs.")

@app.post("/api/admin/reset")
@admin_required
def reset():
    with db() as c:
        c.execute("DELETE FROM ballots")
        c.execute("DELETE FROM voters")
    return jsonify(message="Demo election reset. Existing receipts will no longer verify.")

if __name__ == "__main__":
    app.run(host="127.0.0.1", port=5000, debug=False)
